##Welcome to plateau!

Plateau is a super simple publishing engine designed to get out of the way while you write compelling content.

Each page and post in a plateau site is a directory in /content which contains a markdown file or two and the resources that it needs.

All pages are processed as markdown, though the markdown parser will ignore anything it perceives as html, 
so you can just use html if you like in the .md files, or any combination of the two

Resources can be any of the usual web suspects; images, movies, media, stylesheets and javascript files.