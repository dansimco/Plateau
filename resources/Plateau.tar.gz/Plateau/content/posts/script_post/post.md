Below is an image rendered with canvas by this post's attached javascript.

<canvas id="example_canvas_image"></canvas>

