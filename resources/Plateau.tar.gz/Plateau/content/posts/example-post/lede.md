Hi there I am a *lede* for a longer article. 

It's a good article, you should click through to read it.
