Hey cool! You clicked through to the main post.

Treat yourself to these photos of plateaus, courtesy of google image search[^1]

![A plateau](p1.jpg)

![A plateau](p2.jpg)

![A plateau](p3.jpg)

![A plateau](p4.jpg)

![A plateau](p5.jpg)

![A plateau](p6.jpg)

[^1]: Please don't sue me.